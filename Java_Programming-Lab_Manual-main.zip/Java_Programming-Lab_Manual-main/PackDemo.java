 import pack.Sum; 
class PackDemo 
{
public static void main(String[] args) 
{ 
System.out.println("This program is written by: Mr. Ashutosh Kumar");
Sum s=new Sum(); 
s.getSum(10,20); 
} }