import packagetest.Book; 
 class BookReader
 { 
 public static void main(String[] args) 
 { 
 Book b=new Book(12,15,86); 
 b.book_info(); 
 } 
 }