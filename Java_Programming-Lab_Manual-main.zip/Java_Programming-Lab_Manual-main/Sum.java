package pack; 
 public class Sum 
 { 
 public void getSum(int a,int b) 
 { 
 System.out.println("\nSum Of Two Numbers"+a+" and "+b+"="+(a+b)); 
 } 
 }