class Fibo
{
public static void main(String args[])
{
System.out.println("This Program is written by: Mr. Ashutosh Kumar");
int a,b,temp,n;
a=0;
b=1;
for(n=1;n<=10;n++)
{
System.out.println(a);
temp=a+b;
 a=b;
 b=temp;
}
 }
 }
